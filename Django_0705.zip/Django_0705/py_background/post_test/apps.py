from django.apps import AppConfig


class PostTestConfig(AppConfig):
    name = 'post_test'
